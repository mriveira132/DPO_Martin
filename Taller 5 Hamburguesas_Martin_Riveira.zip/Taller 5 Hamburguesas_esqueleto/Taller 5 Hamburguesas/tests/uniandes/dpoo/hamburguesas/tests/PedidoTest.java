package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class PedidoTest {

    private Pedido pedido;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;

    @BeforeEach
    public void setUp() {
        pedido = new Pedido("Bulma Briefs", "Calle 197");
        hamburguesa = new ProductoMenu("Hamburguesa Trunks", 28000);
        papas = new ProductoMenu("Papas Namek", 3000);
    }

    @Test
    public void testGenerarTextoFactura() {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        String factura = pedido.generarTextoFactura();
        
        assertTrue(factura.contains("Cliente: Bulma Briefs"));
        assertTrue(factura.contains("Dirección: Calle 197"));
        assertTrue(factura.contains("Hamburguesa Trunks"));
        assertTrue(factura.contains("Papas Namek"));
        assertTrue(factura.contains("Precio Total"));
    }

    @Test
    public void testGuardarFactura() throws FileNotFoundException {
        pedido.agregarProducto(hamburguesa);
        pedido.agregarProducto(papas);
        File facturaArchivo = new File("factura_test.txt");
        pedido.guardarFactura(facturaArchivo);

        Scanner scanner = new Scanner(facturaArchivo);
        assertTrue(scanner.hasNextLine());
        scanner.close();

        facturaArchivo.delete();
    }
}
