package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ComboTest {

    private Combo combo;
    private ProductoMenu hamburguesa;
    private ProductoMenu papas;
    private ArrayList<ProductoMenu> itemsCombo;

    @BeforeEach
    public void setUp() {
        hamburguesa = new ProductoMenu("Hamburguesa Frieza", 100000);
        papas = new ProductoMenu("Papas Cooler", 4000);
        itemsCombo = new ArrayList<>();
        itemsCombo.add(hamburguesa);
        itemsCombo.add(papas);
        combo = new Combo("Combo Saiyajin", 0.07, itemsCombo);
    }

    @Test
    public void testGetNombre() {
        assertEquals("Combo Saiyajin", combo.getNombre());
    }

    @Test
    public void testGetPrecio() {
        int precioSinDescuento = hamburguesa.getPrecio() + papas.getPrecio();
        int precioConDescuento = (int)(precioSinDescuento * (1 - 0.07));
        assertEquals(precioConDescuento, combo.getPrecio());
    }

    @Test
    public void testGenerarTextoFactura() {
        String expected = "Combo Combo Saiyajin\\n Descuento: 0.07\\n            " + combo.getPrecio() + "\\n";
        assertEquals(expected, combo.generarTextoFactura());
    }
}
