package mundo;

import java.io.*;
import java.util.ArrayList;

public class ManejadorPersistencia {

    private Discotienda discotienda;

    public ManejadorPersistencia(Discotienda discotienda) {
        this.discotienda = discotienda;
    }

    public void guardarDiscotienda() throws FileNotFoundException {
        PrintWriter escritor = new PrintWriter(new File("./data/discotienda.txt"));
        ArrayList<Disco> discos = discotienda.getDiscos();
        
        for (Disco disco : discos) {
            escritor.println(disco.guardarFormato());

            ArrayList<Cancion> canciones = disco.getCanciones();
            for (Cancion cancion : canciones) {
                escritor.println(cancion.guardarFormato());
            }
        }
        escritor.close();
    }


    public void leerDiscotienda() throws IOException {
        ArrayList<Disco> discos = new ArrayList<Disco>();
        File f = new File("./data/discotienda.txt");
        BufferedReader lector = new BufferedReader(new FileReader(f));

        String linea = lector.readLine();
        Disco discoActual = null;

        while (linea != null) {
            String[] datos = linea.split(";");

            if (!datos[0].equals("CANCION")) {
                discoActual = Disco.cargarDesdeTexto(datos);
                discos.add(discoActual);
            } else {
                Cancion cancion = Cancion.cargarDesdeTexto(datos);
                if (discoActual != null) {
                    discoActual.agregarCancion(cancion);
                }
            }
            linea = lector.readLine();
        }

        lector.close();
        discotienda.setDiscos(discos);
    }
}