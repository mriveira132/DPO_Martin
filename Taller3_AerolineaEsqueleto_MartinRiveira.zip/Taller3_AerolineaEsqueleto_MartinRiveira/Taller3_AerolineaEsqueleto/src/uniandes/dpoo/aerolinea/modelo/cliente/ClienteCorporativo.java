package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.Collection;
import java.util.List;

import org.json.JSONObject;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

/**
 * Esta clase se usa para representar a los clientes de la aerolínea que son empresas
 */
public class ClienteCorporativo extends Cliente
{
    // TODO completar
	private String empresa;
	private int tamanoEmpresa;
	private Collection<?> nombreEmpresa;
	public static final String CORPORATIVO = "Corporativo";
	public static final int GRANDE = 1;
	public static final int MEDIANA = 2;
	public static final int PEQUENA = 3;
	
    


    public ClienteCorporativo(List<Tiquete> tiqueteSinUsar, List<Tiquete> tiquetesUsados, String empresa,
			int tamanoEmpresa) {
		super(tiqueteSinUsar, tiquetesUsados);
		this.empresa = empresa;
		this.tamanoEmpresa = tamanoEmpresa;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public int getTamanoEmpresa() {
		return tamanoEmpresa;
	}

	public void setTamanoEmpresa(int tamanoEmpresa) {
		this.tamanoEmpresa = tamanoEmpresa;
	}

	public static String getCorporativo() {
		return CORPORATIVO;
	}

	public static int getGrande() {
		return GRANDE;
	}

	public static int getMediana() {
		return MEDIANA;
	}

	public static int getPequena() {
		return PEQUENA;
	}
	public void getIdentificador() {
	}
	
	public void getTipoCliente() {
	}
	public void getTamanoEmpresa1(){
	}

	public ClienteCorporativo(String empresa, int tamanoEmpresa) {
		super(getTiqueteSinUsar(), getTiqueteSinUsar());
		this.empresa = empresa;
		this.tamanoEmpresa = tamanoEmpresa;
	}

	/**
     * Crea un nuevo objeto de tipo a partir de un objeto JSON.
     * 
     * El objeto JSON debe tener dos atributos: nombreEmpresa (una cadena) y tamanoEmpresa (un número).
     * @param cliente El objeto JSON que contiene la información
     * @return El nuevo objeto inicializado con la información
     */
    public static ClienteCorporativo cargarDesdeJSON( JSONObject cliente )
    {
        String nombreEmpresa = cliente.getString( "nombreEmpresa" );
        int tam = cliente.getInt( "tamanoEmpresa" );
        return new ClienteCorporativo( nombreEmpresa, tam );
    }
    public void cargarDesdeJSON1(JSONObject cliente) {
	}

    /**
     * Salva este objeto de tipo ClienteCorporativo dentro de un objeto JSONObject para que ese objeto se almacene en un archivo
     * @return El objeto JSON con toda la información del cliente corporativo
     */
    public JSONObject salvarEnJSON( )
    {
        JSONObject jobject = new JSONObject( );
        jobject.put( "nombreEmpresa", this.nombreEmpresa );
        jobject.put( "tamanoEmpresa", this.tamanoEmpresa );
        jobject.put( "tipo", CORPORATIVO );
        return jobject;
    }

	@Override
	public void agregarTiquete(Tiquete tiquete) {
		// TODO Auto-generated method stub
		
	}
}
