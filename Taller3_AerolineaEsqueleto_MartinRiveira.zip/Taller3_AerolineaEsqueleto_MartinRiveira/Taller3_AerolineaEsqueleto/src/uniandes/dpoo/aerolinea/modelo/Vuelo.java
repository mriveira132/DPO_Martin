package uniandes.dpoo.aerolinea.modelo;

import java.util.List;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	private String fecha;
	private Avion avion;
	private Ruta ruta;
	private List<Tiquete> tiquetes;
	
	
	public String getFecha() {
		return fecha;
	}


	public void setFecha(String fecha) {
		this.fecha = fecha;
	}


	public Avion getAvion() {
		return avion;
	}


	public void setAvion(Avion avion) {
		this.avion = avion;
	}


	public Ruta getRuta() {
		return ruta;
	}


	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}


	public List<Tiquete> getTiquetes() {
		return tiquetes;
	}


	public void setTiquetes(List<Tiquete> tiquetes) {
		this.tiquetes = tiquetes;
	}


	public Vuelo(String fecha, Avion avion, Ruta ruta, List<Tiquete> tiquetes) {
		super();
		this.fecha = fecha;
		this.avion = avion;
		this.ruta = ruta;
		this.tiquetes = tiquetes;
	}


	public Vuelo(String fecha2, String codigoRuta, Avion avion2) {
		// TODO Auto-generated constructor stub
	}


	public int venderTiquetes(Cliente cliente, int cantidad) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
