package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	private List<Tiquete> tiqueteSinUsar;
	private List<Tiquete> tiquetesUsados;
	public abstract void agregarTiquete(Tiquete tiquete);
	public List<Tiquete> getTiqueteSinUsar() {
		return tiqueteSinUsar;
	}
	public void setTiqueteSinUsar(List<Tiquete> tiqueteSinUsar) {
		this.tiqueteSinUsar = tiqueteSinUsar;
	}
	public List<Tiquete> getTiquetesUsados() {
		return tiquetesUsados;
	}
	public void setTiquetesUsados(List<Tiquete> tiquetesUsados) {
		this.tiquetesUsados = tiquetesUsados;
	}
	public Cliente(List<Tiquete> tiqueteSinUsar, List<Tiquete> tiquetesUsados) {
		super();
		this.tiqueteSinUsar = tiqueteSinUsar;
		this.tiquetesUsados = tiquetesUsados;
	
	}
	public String getIdentificador() {
		// TODO Auto-generated method stub
		return null;
	}
	public char[] calcularSaldoPendiente() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
