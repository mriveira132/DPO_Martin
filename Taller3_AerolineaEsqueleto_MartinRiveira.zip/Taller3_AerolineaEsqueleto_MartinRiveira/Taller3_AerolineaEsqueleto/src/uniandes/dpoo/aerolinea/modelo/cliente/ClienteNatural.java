package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;

import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class ClienteNatural extends Cliente {
	public static String NATURAL = "Natural";
	private String nombre;
	public static String getNATURAL() {
		return NATURAL;
	}
	public static void setNATURAL(String nATURAL) {
		NATURAL = nATURAL;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public ClienteNatural(List<Tiquete> tiqueteSinUsar, List<Tiquete> tiquetesUsados, String nombre) {
		super(tiqueteSinUsar, tiquetesUsados);
		this.nombre = nombre;
	}
	public void getIdentificador() {
	}
	
	public void getTipoCliente() {
	}
	@Override
	public void agregarTiquete(Tiquete tiquete) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
