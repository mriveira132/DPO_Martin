package uniandes.dpoo.aerolinea.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta implements CalculadoraTarifas {
	protected int COSTO_POR_KM = 1000;

	@Override
	public void calcularTarifa(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularPorcentajeDescuento(Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularDistanciaVuelo(Ruta ruta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularValorImpuestos(int costoBase) {
		// TODO Auto-generated method stub
		
	}

}
