package uniandes.dpoo.aerolinea.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja implements CalculadoraTarifas {
	protected int COSTO_POR_KM_NATURAL = 600;
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	protected double DESCUENTO_PEQ = 0.02;
	protected double DESCUENTO_MEDIANAS = 0.1;
	protected double DESCUENTO_GRANDES = 0.2;

	@Override
	public void calcularTarifa(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularCostoBase(Vuelo vuelo, Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularPorcentajeDescuento(Cliente cliente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularDistanciaVuelo(Ruta ruta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcularValorImpuestos(int costoBase) {
		// TODO Auto-generated method stub
		
	}
	

}
