package uniandes.dpoo.aerolinea.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public interface CalculadoraTarifas {
	static double IMPUESTO = 0.28;
	public void calcularTarifa(Vuelo vuelo, Cliente cliente);
	abstract void calcularCostoBase(Vuelo vuelo, Cliente cliente);
	abstract void calcularPorcentajeDescuento(Cliente cliente);
	void calcularDistanciaVuelo(Ruta ruta);
	void calcularValorImpuestos(int costoBase);
	public static double getIMPUESTO() {
		return IMPUESTO;
	}
	

}
